import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  regForm: FormGroup;

  msg = '';

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private service: AuthService
  ) { }

  initForm() {
    this.regForm = this.fb.group({
        username:  ['', [Validators.required, Validators.minLength(3), Validators.maxLength(100)]],
        password:  ['', [Validators.required, Validators.minLength(5), Validators.maxLength(100)]]
    });
  }

  ngOnInit() {
    this.initForm();
  }

  onError(err) {
    this.msg = err;
  }

  onSuccess() {
    this.router.navigate(['/login']);
  }

  onSubmit() {
    if (this.regForm.invalid) { return; }
    this.service.login(this.regForm.getRawValue()).subscribe(
      (data) => this.onSuccess(),
      (err) => this.onError(err)
    );
  }

}
