import { Component, OnInit } from '@angular/core';
import { ActivityService } from '../services/activity.service';
import { Activity, Category } from '../models/config';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  activity = [];

  aktForm: FormGroup;

  msg = '';

  catEnum = Category;

  modalState = false;

  constructor(
    private fb: FormBuilder,
    private serviceAct: ActivityService,
    private modalService: NgbModal
  ) { }

  initForm() {
    this.aktForm = this.fb.group({
      Title:  ['', [Validators.required, Validators.min(0), Validators.max(50)]],
      Points:  ['', [Validators.required, Validators.min(0), Validators.max(100)]],
      Description:  ['', [Validators.required, Validators.minLength(5), Validators.maxLength(500)]],
      Type:  true,
      Active: false,
      CategoryId: [0, Validators.required],
    });
  }

  ngOnInit() {
    this.initForm();

    // this.serviceAct.get().subscribe(
    //   (data: Activity[]) => this.activity = data
    // );
  }

  modalSave() {
    if (this.aktForm.invalid) {
      this.msg = 'Внесовте невалидни податоци!';
      return;
    }
    this.modalState = false;
    const data = this.aktForm.getRawValue();
    data.CategoryId = Number(data.CategoryId);

    console.log(data);
  }

  changeRadio(type) {
    this.aktForm.patchValue({
      Type: type
    })
  }

}
