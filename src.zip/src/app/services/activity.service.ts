import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { URLS } from '../../assets/URLS';

@Injectable()
export class ActivityService {

  constructor(
    private http: HttpClient
  ) { }

  get() {
    return this.http.get(URLS.ACTIVITY);
  }

  post(params) {
    this.http.post(URLS.ACTIVITY, params);
  }

  delete(params) {
    this.http.delete(URLS.ACTIVITY, params);
  }
}
