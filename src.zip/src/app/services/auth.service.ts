import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { URLS } from '../../assets/URLS';

@Injectable()
export class AuthService {

  constructor(
    private http: HttpClient
  ) { }

  login(params) {
    return this.http.put(URLS.LOGIN, params);
  }

  logout() {
    this.http.delete(URLS.LOGIN);
  }

  register(params) {
    return this.http.post(URLS.REGISTER, params);
  }
}
