import { Pipe, PipeTransform } from '@angular/core';
import { keys } from 'lodash';

@Pipe({
  name: 'enumToArray'
})
export class EnumToArrayPipe implements PipeTransform {
  transform(data: object, dataKeys?: boolean) {
    const key = keys(data);
    if (dataKeys) {
      const reverse = key.reverse();
      return reverse.slice(reverse.length / 2).reverse();
    }
    return key.slice(key.length / 2);
  }
}
