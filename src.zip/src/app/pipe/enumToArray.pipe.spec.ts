/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { EnumToArrayPipe } from './enumToArray.pipe';

describe('Pipe: EnumToArraye', () => {
  it('create an instance', () => {
    let pipe = new EnumToArrayPipe();
    expect(pipe).toBeTruthy();
  });
});
