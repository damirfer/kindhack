export interface IActivity {
    Points: number;
    Title: string;
    Description: string;
    Active: boolean;
    CategoryId: number;
}

export class Activity implements IActivity {
    constructor(
        public Points: number,
        public Title: string,
        public Description: string,
        public Active: boolean,
        public CategoryId: number,
    ) {}
}

export enum Category {
    'Возев велосипед/тротинет/пешачев',
    'Се возев со автобус',
    'Селектирав отпад',
    'Купив локален производ',
    'Направив куќарка за птици',
    'Ја донирав старата облека',
    'Учествував во акција за чистење',
    'Учествував во акции за садење дрвја'
}
