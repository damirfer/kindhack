import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;

  msg = '';

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private service: AuthService
  ) { }

  initForm() {
    this.loginForm = this.fb.group({
        username:  ['', [Validators.required, Validators.minLength(3), Validators.maxLength(100)]],
        password:  ['', [Validators.required, Validators.minLength(5), Validators.maxLength(100)]]
    });
  }

  ngOnInit() {
    this.initForm();
  }

  onError(err) {
    this.msg = err;
  }

  onSuccess(data) {
    localStorage.setItem('currentUser', JSON.stringify(data));
    this.router.navigate(['/']);
  }

  onSubmit() {
    if (this.loginForm.invalid) { return; }
    this.service.login(this.loginForm.getRawValue()).subscribe(
      (data) => this.onSuccess(data),
      (err) => this.onError(err)
    );
  }

}
