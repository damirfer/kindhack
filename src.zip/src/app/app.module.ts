import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { BootstrapModule } from './bootstrap.module';
import { NavbarComponent } from './navbar/navbar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';

import { AuthService } from './services/auth.service';
import { ActivityService } from './services/activity.service';
import { EnumToArrayPipe } from './pipe/enumToArray.pipe';

@NgModule({
   declarations: [
      AppComponent,
      NavbarComponent,
      DashboardComponent,
      LoginComponent,
      RegisterComponent,
      AdminComponent,
      UserComponent,
      EnumToArrayPipe
   ],
   imports: [
      BrowserModule,
      AppRoutingModule,
      NgbModule.forRoot(),
      BootstrapModule,
      ReactiveFormsModule,
      HttpClientModule
   ],
   providers: [
    AuthService,
    ActivityService
   ],
   bootstrap: [
      AppComponent
   ]
})
export class AppModule { }
