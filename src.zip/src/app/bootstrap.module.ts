import { NgModule } from '@angular/core';

import {
  NgbAlertModule,
} from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    NgbAlertModule
  ],
  exports: [
    NgbAlertModule
  ],
})
export class BootstrapModule { }
