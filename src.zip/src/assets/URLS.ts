export const URL = 'api';

export const URLS = {
    // LOGIN
    LOGIN: URL + '/user/login',
    REGISTER: URL + '/user/register',

    ACTIVITY: URL + '/activity',
};
